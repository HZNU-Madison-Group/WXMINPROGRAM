// pages/SM/SM.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Title:'',
    Author:'',
    Price:'',
    Isbn:'',
    EX:'',//是否存在
    Logo:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.scanCode({
      onlyFromCamera:true,
      success:function(res){
        wx.request({
          url: 'https://www.98api.cn/api/isbn.php',
          data:{
            isbn:res.result
          },
          success:function(r){
            console.log(r)
            that.setData({
              Title: r.data.title,
              Author: r.data.author,
              Price: r.data.price,
              Isbn:res.result,
              Logo:r.data.logo
            });


            //查询是否已经存在该书籍
            wx.request({
              url: 'http://172.22.130.33/index.php/Ajaxapi/Ajaxapi/searchbook',
              data:{
                isbn:res.result
              },
              
              success:function(rr){
              //若存在则则跳转页面显示该书籍内容
              //如不存在则显示跳转内容，再加入库
                if (rr.data.data != null){
                  that.setData({
                    EX:T
                  })}
                else {
                  that.setData({
                    EX: F
                  })
                }
                  //缓存信息
                  wx.setStorageSync('title',Title);
                  wx.setStorageSync('author',Author);
                  wx.setStorageSync('price', Price);
                  wx.setStorageSync('isbn',Isbn);
                  wx.setStorageSync('ex', EX);
                wx.setStorageSync('logo', Logo);
                  //跳转页面
                  wx.navigateTo({
                    url: '/pages/XS/XS',
                  })
                  console.log("111111")
              },
              fail:function(){
                console.log("失败")
              }
            })
          },

        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})