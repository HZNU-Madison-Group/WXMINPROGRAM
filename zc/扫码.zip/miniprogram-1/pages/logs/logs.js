//logs.js
const util = require('../../utils/util.js')

Page({
  data: {
    
  },
  onLoad: function () {

  },

  clicktoSM:function(){
    var that=this
    wx.navigateTo({
      url: '/pages/SM/SM',
    })
  },
 
})
