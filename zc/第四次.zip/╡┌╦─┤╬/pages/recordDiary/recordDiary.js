// pages/recordDiary/recordDiary.js
Page({

  /**
   * Page initial data
   */
  data: {
    index: '',
    str: [],
    diary: '',
    reason_input: '',
    id: '',
    diaryy:'',
    itemm:''
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    var that = this;
    var str = this.data.str
   wx.getStorage({
  key: 'ddd',
  success: function (res) {
    console.log(res.data)
    that.setData({
      diaryy: res.data
    });  // 在这里打印出存储的值；
  }
})
    wx.getStorage({
      key: 'strr',
      success: res => {
        this.setData({
          str: res.data
        });
        console.log(res.data)
      },
    })

    wx.request({
    url:"http://172.22.130.33/index.php/Ajaxapi/Ajaxapi/browsereplybyid/",
    data:{
      pid:2
    },
    success: function (res) {
      var array = res.data.data
      var itemm = that.data.itemm
      array.forEach((item, index) => {
        itemm = item
        that.setData({
          itemm: itemm,
        })
      })
      that.setData({
        str: res.data.data
      })
    },
    })
  },
  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
   
    wx.getStorage({
      key: 'id',
      success: res => {
        this.setData({
          id: res.data
        });
      }})
    var that = this;
    wx.getStorage({
      key: 'index',
      success: res => {
        that.setData({
          index: res.data
        });
        console.log(res.data)
      },
    })
    


  },


  //增加回复
  rapid: function (e) {
    var that = this
    var reason_input = that.data.reason_input
    reason_input = e.detail.value
    wx.setStorage({
      key: 'input',
      data: reason_input,
    })
    this.setData({
      reason_input: reason_input
    })
  },

  save: function (e) {
    var that = this
    console.log(e)
    wx.request({
      url: 'http://172.22.130.33/index.php/Ajaxapi/Ajaxapi/createproblem',
      data: {
        authorid: that.data.pid
      },
      success: function (res) {
        console.log(res.data)
        var pages = getCurrentPages();
        var prevPage = pages[pages.length - 2];
        wx.navigateBack({
          delta: 1
        })
      },
    })
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})