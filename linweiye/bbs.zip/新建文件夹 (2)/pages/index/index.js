Page({
  data: {
    flag:'1',
    way:'发布动态'
  },
  selectWay:function(){
    this.setData({flag:'0'});
  },
  fabuChange:function(e){
    console.log(e);
    var way=e.detail.value;
    this.setData({flag:'1'});
    this.setData({wat:way});
  },
  formSubmit:function(e){
    console.log(e);
    var data = e.detail.value;
    data.way=this.data.way;
    wx.setStorageSync('data', data)
  },
  switchNav:function(e){
    console.log(e);
    var page=this;
    var id=e.target.id;
    if(this.data.currentTab==id){
      return false;
    }else{
      page.setData({currentTab:id});
    }
    page.setData({ flag: id });
  },

    onShareAppMessage:function(){
      return{
        title:'A的论坛',
        desc:'畅所欲言',
        path:'index/index'
      }
    }
})
   