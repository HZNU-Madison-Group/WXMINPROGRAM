// pages/view/view.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    luntan: '',
    dd: ''
  },
  clickreply: function (e) {
    app.globalData.pid = e.target.dataset.id;
    wx.navigateTo({
      url: '/pages/reply/reply',
    })
  },

  clickdelete: function () {
    wx.request({
      url: 'http://172.22.130.33/index.php/Ajaxapi/Ajaxapi/deleteproblembyid/userid/' + app.globalData.userid + '/pid/' + app.globalData.userid,
      success: function (res) {
        if (res.data.info == 1) {
          wx.showToast({
            title: '删除成功',
            icon: 'none',
            duration: 8000,
          })
        } else {
          wx.showToast({
            title: '失败',
            icon: 'none',
            duration: 8000
          })
        }
      }
    })
  },

  clickchakan: function (e) {
    app.globalData.pid = e.target.dataset.id;

    var that = this
    wx.request({
      url: 'http://172.22.130.33/index.php/Ajaxapi/Ajaxapi/browsereplybyid/pid/' + app.globalData.pid,
      success: function (res) {

        if (res.data.info == 1) {
          that.setData({
            luntan: res.data.data
          })
          wx.showToast({
            title: '成功',
            icon: 'none',
            duration: 8000,
          })
        } else {
          wx.showToast({
            title: '未找到相应的论坛',
            icon: 'none',
            duration: 8000
          })
        }
      }
    })
  },

  clickchaxun: function () {
    var that = this
    wx.request({
      url: 'http://172.22.130.33/index.php/Ajaxapi/Ajaxapi/browserroot',
      success: function (res) {

        if (res.data.info == 1) {
          that.setData({
            luntan: res.data.data
          })
          wx.showToast({
            title: '成功',
            icon: 'none',
            duration: 8000,
          })
        } else {
          wx.showToast({
            title: '未找到相应的论坛',
            icon: 'none',
            duration: 8000
          })
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      dd: app.globalData.userid
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})